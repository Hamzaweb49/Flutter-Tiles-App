import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:tiles_app/constant/app_assets.dart';
import 'package:tiles_app/constant/app_color.dart';
import 'package:tiles_app/constant/app_string.dart';
import 'package:tiles_app/controller/products_controller.dart';
import 'package:tiles_app/utils/app_routes.dart';
import 'package:tiles_app/utils/extension.dart';
import 'package:tiles_app/widgets/app_appbar.dart';
import 'package:tiles_app/widgets/app_bottom_navigator.dart';
import 'package:tiles_app/widgets/app_container.dart';

class ProductsScreen extends StatefulWidget {
  const ProductsScreen({super.key});

  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  final ProductsController productsController = Get.put(ProductsController());
  int categoryId = 0;
  String categoryName = '';

  @override
  void initState() {
    super.initState();
    categoryId = Get.arguments['categoryId'] ?? 0;
    categoryName = Get.arguments['categoryName'] ?? '';
    productsController.getSubCategory(categoryId);
    productsController.getAllProducts();
  }

  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;

    return AppContainer(
      child: SafeArea(
        child: Scaffold(
          appBar: CommonAppBar(
            h: h,
            w: w,
            title: categoryName.isNotEmpty ? categoryName : 'Products',
          ),
          body: Obx(() {
            if (productsController.isLoading.value) {
              return const Center(child: CircularProgressIndicator());
            }

            return Container(
              // color: const Color(0xFFF4F4F4),
              padding: EdgeInsets.symmetric(horizontal: w * 0.040),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 8),
                  if (productsController.subCategories.isNotEmpty) ...[
                    Container(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: productsController.subCategories
                              .map((subCategory) {
                            return Container(
                              margin: const EdgeInsets.only(right: 15),
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: appColor,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text(
                                subCategory['name'],
                                style: const TextStyle(
                                  fontSize: 14,
                                  color: Colors.white,
                                  fontFamily: 'Montserrat',
                                  fontWeight: FontWeight.w600,
                                  decoration: TextDecoration.none,
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                  ],
                  const SizedBox(height: 20),
                  if (productsController.products.isNotEmpty) ...[
                    Text(
                      "Total products: ${productsController.products.length}",
                      style: const TextStyle(
                        fontSize: 17,
                        fontFamily: 'Montserrat',
                        fontWeight: FontWeight.w600, // Bold weight
                        color: Colors.black,
                      ),
                    ),
                  ],
                  const SizedBox(height: 20),
                  if (productsController.products.isNotEmpty) ...[
                    Expanded(
                      child: GridView.builder(
                        itemCount: productsController.products.length,
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 16,
                          mainAxisSpacing: 16,
                          childAspectRatio: 0.7,
                        ),
                        itemBuilder: (context, index) {
                          final product = productsController.products[index];

                          final imageUrl =
                              product['productImageList']?.isNotEmpty == true
                                  ? product['productImageList'][0]['imageURL']
                                  : 'https://placeholder.com/placeholder.png';
                          return GestureDetector(
                            onTap: () {
                              // Navigate to ProductDetails page with the product ID
                              Get.toNamed(
                                Routes.productDetailsScreen,
                                arguments: {'id': product['id']},
                              );
                            },
                            child: Container(
                              // Outer container with padding and gray border
                              padding: const EdgeInsets.all(
                                  8), // Padding from all sides
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                    color: const Color.fromARGB(
                                        255, 224, 224, 224)), // Gray border
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.1),
                                    spreadRadius: 1,
                                    blurRadius: 4,
                                    offset: const Offset(0, 3),
                                  ),
                                ],
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(
                                          10), // Rectangular shape
                                      child: Image.network(
                                        imageUrl,
                                        fit: BoxFit.cover,
                                        width: double.infinity,
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(5),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          product['series'] ?? '',
                                          style: const TextStyle(
                                            fontFamily: 'Montserrat',
                                            fontWeight: FontWeight.bold,
                                            fontSize: 16,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          product['name'] ?? 'Product Name',
                                          style: const TextStyle(
                                            fontFamily: 'Montserrat',
                                            fontWeight: FontWeight.w600,
                                            fontSize: 15,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          '${product['size'] ?? 'N/A'}',
                                          style: const TextStyle(
                                            fontFamily: 'Montserrat',
                                            fontSize: 14,
                                          ),
                                        ),
                                        const SizedBox(height: 8),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              '${product['weight'] ?? 'N/A'}',
                                              style: const TextStyle(
                                                fontFamily: 'Montserrat',
                                                fontSize: 14,
                                                color: redColor,
                                              ),
                                            ),
                                            Text(
                                              '₹${product['price'] ?? 'N/A'}',
                                              style: const TextStyle(
                                                fontFamily: 'Montserrat',
                                                fontSize: 17,
                                                fontWeight: FontWeight.bold,
                                                color: appColor,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ],
              ),
            );
          }),
          bottomNavigationBar: BottomNavigationBarWidget(
            selectedIndex: _selectedIndex,
            onItemTapped: _onItemTapped,
          ),
        ),
      ),
    );
  }
}
