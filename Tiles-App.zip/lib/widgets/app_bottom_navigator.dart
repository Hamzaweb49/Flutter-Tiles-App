// bottom_navigation_bar.dart

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:tiles_app/constant/app_color.dart';
import 'package:tiles_app/utils/app_routes.dart';

class BottomNavigationBarWidget extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onItemTapped;

  const BottomNavigationBarWidget({
    Key? key,
    required this.selectedIndex,
    required this.onItemTapped,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10), // Padding around the bar
      color: appColor,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround, // Space between icons
        children: [
          _buildBottomNavItem(Icons.home, 'Home', 0),
          _buildBottomNavItem(Icons.search, 'Search', 1),
          _buildBottomNavItem(Icons.favorite, 'Favorites', 2),
          _buildBottomNavItem(Icons.person, 'Profile', 3),
        ],
      ),
    );
  }

  Widget _buildBottomNavItem(IconData icon, String label, int index) {
    return GestureDetector(
      onTap: () {
        if (index == 0) {
          Get.toNamed(
              Routes.homeScreen); // Navigate to HomeScreen using Get.toNamed
        } else {
          onItemTapped(
              index); // Call the provided onItemTapped callback for other buttons
        }
      },
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 28, color: Colors.white), // Icon size and color
          const SizedBox(height: 4), // Space between icon and text
          Text(label,
              style: const TextStyle(color: Colors.white)), // Text style
        ],
      ),
    );
  }
}
