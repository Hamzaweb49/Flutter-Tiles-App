import 'package:get/get.dart';
import 'package:tiles_app/ui/categories_list_screen.dart';
import 'package:tiles_app/ui/home_screen.dart';
import 'package:tiles_app/ui/location_screen.dart';
import 'package:tiles_app/ui/product_details_screen.dart';
import 'package:tiles_app/ui/products_screen.dart';
import 'package:tiles_app/ui/splash_screen.dart';

class Routes {
  static String splashScreen = "/";
  static String homeScreen = "/homeScreen";
  static String locationScreen = "/locationScreen";
  static String categoriesListScreen = "/categoriesListScreen";
  static String productScreen = "/productScreen";
  static String productDetailsScreen = "/productDetailsScreen";

  static List<GetPage> routes = [
    GetPage(
        name: splashScreen,
        page: () => const SplashScreen(),
        transition: Transition.fadeIn),
    GetPage(
        name: homeScreen,
        page: () => const HomeScreen(),
        transition: Transition.fadeIn),
    GetPage(
        name: locationScreen,
        page: () => const LocationScreen(),
        transition: Transition.downToUp),
    GetPage(
        name: categoriesListScreen,
        page: () => const CategoriesListScreen(),
        transition: Transition.fadeIn),
    GetPage(
        name: productScreen,
        page: () => const ProductsScreen(),
        transition: Transition.upToDown),
    GetPage(
        name: productDetailsScreen,
        page: () => const ProductDetailsScreen(),
        transition: Transition.fadeIn),
  ];
}
