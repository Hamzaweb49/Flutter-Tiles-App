import 'package:flutter/material.dart';

const Color whiteColor = Color(0xffFFFFFF);
const Color blackColor = Color(0xff000000);
const Color appColor = Color(0xff0e475c);
const Color secondaryAppColor = Color(0xff72ef36);
const Color redColor = Color(0xffe75462);
const Color greyColor = Colors.grey;
const Color blueAccentColor = Colors.blueAccent;
