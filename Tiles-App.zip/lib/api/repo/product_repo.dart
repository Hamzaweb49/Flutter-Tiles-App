import 'dart:io';

import 'package:tiles_app/api/api_helpers.dart';
import 'package:tiles_app/constant/app_request.dart';
import 'package:tiles_app/model/response_item.dart';

///GET ALL Location Products
class GetAllProduct {
  static Future<ResponseItem> getAllProduct() async {
    ResponseItem result = ResponseItem();
    String requestUrl = AppUrls.BASE_URL + MethodNames.getAllProduct;
    result = await BaseApiHelper.getRequest(requestUrl);
    return result;
  }
}

/// GET Product Details
class GetProductDetailsRepo {
  static Future<ResponseItem> getProductDetailsRepo({required int id}) async {
    ResponseItem result = ResponseItem();
    String requestUrl =
        AppUrls.BASE_URL + MethodNames.getProductById + id.toString();
    result = await BaseApiHelper.getRequest(requestUrl);
    return result;
  }
}

/// Upload Images
class UploadImageRepo {
  static Future<ResponseItem> uploadImagesRepo(
      {required List<File> requestData}) async {
    ResponseItem result = ResponseItem();

    String requestUrl = AppUrls.BASE_URL + MethodNames.uploadProductImage;
    result = await BaseApiHelper.uploadImages(
        requestUrl: requestUrl, requestData: requestData);
    return result;
  }
}

/// Add Product
class AddBookRepo {
  static Future<ResponseItem> addProductRepo(
      {required Map<String, dynamic> productData}) async {
    ResponseItem result = ResponseItem();

    String requestUrl = AppUrls.BASE_URL + MethodNames.addProduct;
    result = await BaseApiHelper.postRequest(requestUrl, productData);
    return result;
  }
}
